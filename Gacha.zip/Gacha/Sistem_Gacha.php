<?php
// Detail koneksi database
$host = "localhost"; // Host database
$username = "root"; // Username untuk koneksi
$password = ""; // Password untuk koneksi
$database = "mudaefinal_database"; // Nama database yang digunakan

// Membuat koneksi
$conn = new mysqli($host, $username, $password, $database);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error); // Menampilkan pesan error jika koneksi gagal
}

session_start(); // Memulai sesi

$listOpen = false; // Inisialisasi variabel untuk menentukan apakah daftar terbuka

// Fungsi untuk menghasilkan karakter secara acak
function generateWaifu($conn) {
    if (isset($_POST['action']) && $_POST['action'] == 'generate') { // Memeriksa apakah aksi 'generate' dipanggil
        $randomRank = rand(1, 100); // Menghasilkan peringkat acak antara 1 dan 100
        $sql = "SELECT * FROM waifu WHERE RANK = $randomRank"; // Query untuk mengambil karakter berdasarkan peringkat acak
        $result = $conn->query($sql); // Menjalankan query

        if ($result && $result->num_rows > 0) { // Memeriksa apakah hasil query ada
            $row = $result->fetch_assoc(); // Mengambil baris hasil query sebagai array asosiatif
            $stat = ($row['STAT'] == 0) ? "Unclaimed" : "Claimed"; // Menentukan status karakter
            echo "#{$row['RANK']} {$row['NAME']} {$row['SERIES']} {$row['KAKERA']} $stat<br>"; // Menampilkan informasi karakter

            if ($row['STAT'] == 0) { // Jika karakter belum diklaim
                echo "<form method='post'>"; // Membuat form untuk klaim karakter
                echo "<input type='hidden' name='rank' value='{$row['RANK']}'>"; // Menyimpan peringkat karakter yang akan diklaim
                echo "<input type='submit' name='action' value='Claim'>"; // Tombol klaim
                echo "<input type='submit' name='action' value='Abandon'>"; // Tombol menyerah
                echo "</form>";
            } else {
                echo "Karakter ini sudah diklaim, tarik yang lain<br>"; // Pesan jika karakter sudah diklaim
            }
        } else {
            echo "Error: Tidak ada karakter ditemukan untuk peringkat $randomRank<br>"; // Pesan jika tidak ada karakter yang ditemukan
        }
    }
}

// Fungsi untuk mengklaim karakter
function claimWaifu($conn, $rank) {
    $updateSql = "UPDATE waifu SET STAT = 1 WHERE RANK = $rank"; // Query untuk mengubah status karakter menjadi 'Claimed'
    if ($conn->query($updateSql) === TRUE) { // Menjalankan query dan memeriksa apakah berhasil
        echo "You just claimed this character, wooho!<br>"; // Pesan jika berhasil klaim
    } else {
        echo "Error memperbarui catatan: " . $conn->error . "<br>"; // Pesan jika ada error saat memperbarui
    }
}

// Fungsi untuk menampilkan daftar karakter
function listWaifus($conn) {
    $sql = "SELECT * FROM waifu"; // Query untuk mengambil semua karakter
    $result = $conn->query($sql); // Menjalankan query

    if ($result && $result->num_rows > 0) { // Memeriksa apakah hasil query ada
        while($row = $result->fetch_assoc()) { // Mengambil setiap baris hasil query
            $stat = ($row['STAT'] == 0) ? "Unclaimed" : "Claimed"; // Menentukan status karakter
            echo "#{$row['RANK']} {$row['NAME']} {$row['SERIES']} {$row['KAKERA']} $stat<br>"; // Menampilkan informasi karakter
        }
    } else {
        echo "Error: Tidak ada karakter ditemukan<br>"; // Pesan jika tidak ada karakter yang ditemukan
    }
}

// Menangani pengiriman form
if ($_SERVER["REQUEST_METHOD"] == "POST") { // Memeriksa apakah form dikirim
    if (isset($_POST['action'])) { // Memeriksa apakah ada aksi yang dilakukan
        if ($_POST['action'] == 'generate') { // Jika aksi adalah 'generate'
            generateWaifu($conn); // Panggil fungsi untuk menghasilkan karakter
        } elseif ($_POST['action'] == 'Claim' && isset($_POST['rank'])) { // Jika aksi adalah 'Claim'
            claimWaifu($conn, $_POST['rank']); // Panggil fungsi untuk klaim karakter
        } elseif ($_POST['action'] == 'Abandon') { // Jika aksi adalah 'Abandon'
            echo "Did you just abandon her?<br>"; // Pesan jika menyerah
        } elseif ($_POST['action'] == 'Open List' || $_POST['action'] == 'Close List') { // Jika aksi untuk membuka atau menutup daftar
            if (isset($_SESSION['listOpen']) && $_SESSION['listOpen']) { // Jika daftar sudah terbuka
                $_SESSION['listOpen'] = false; // Tutup daftar
                echo "Daftar ditutup<br>"; // Pesan menutup daftar
            } else {
                $_SESSION['listOpen'] = true; // Buka daftar
            }
        }
    }
}

// Form HTML
?>
<!DOCTYPE html>
<html>
<body>
    <form method="post">
        <input type="submit" name="action" value="generate"> <!-- Tombol untuk menghasilkan karakter -->
        <?php if (isset($_SESSION['listOpen']) && $_SESSION['listOpen']) { ?> <!-- Memeriksa status daftar -->
            <input type="submit" name="action" value="Close List"> <!-- Tombol untuk menutup daftar -->
        <?php } else { ?>
            <input type="submit" name="action" value="Open List"> <!-- Tombol untuk membuka daftar -->
        <?php } ?>
    </form>
    <?php if (isset($_SESSION['listOpen']) && $_SESSION['listOpen']) { ?> <!-- Jika daftar terbuka -->
        <h2>Character List</h2>
        <ul>
            <?php listWaifus($conn); ?> <!-- Menampilkan daftar karakter -->
        </ul>
    <?php } ?>
</body>
</html>

<?php
// Menutup koneksi
$conn->close(); // Menutup koneksi ke database
?>
